package com.sujeet.module.test;

import com.sujeet.module.Generic;
import com.sujeet.module.HelloWorld;
import com.sujeet.nonmodule.Test;


public class HelloWorldTest {
	
	public static void main(String[] args) {
		HelloWorld hello = new HelloWorld();
		hello.sayGoodMorning();
		
		Generic gen = new Generic();
		gen.sayHello();
		
		Test ob = new Test();
	}
	
	public void helloWorldTest() {
		System.out.println("Inside helloworldtest....");
	}

}
