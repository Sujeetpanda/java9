/**
 * 
 */
/**
 * @author sujpanda
 *
 */
module HelloWorldTest {
	requires transitive HelloWorld;
	exports com.sujeet.module.test;
}