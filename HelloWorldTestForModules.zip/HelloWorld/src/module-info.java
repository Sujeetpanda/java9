/**
 * 
 */
/**
 * @author sujpanda
 *
 */
module HelloWorld {
	exports com.sujeet.module;
	exports com.sujeet.nonmodule;
}