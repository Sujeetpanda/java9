package com.sujeet.module;

public class Generic {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	public void sayHello() {
		System.out.println("Hello");
	}

}
