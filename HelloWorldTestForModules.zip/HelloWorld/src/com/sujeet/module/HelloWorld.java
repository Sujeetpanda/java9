package com.sujeet.module;

import com.sujeet.nonmodule.Test;

public class HelloWorld {
	public static void main(String[] args) {
		System.out.println("Hello world");
		Test ob = new Test();
	}

	public void sayGoodMorning() {
		System.out.println("Hi... Good morning");
	}
}
